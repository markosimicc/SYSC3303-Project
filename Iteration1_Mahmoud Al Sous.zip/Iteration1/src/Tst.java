/**
 * @author Marko
 *
 */
public class Tst {
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		Thread floor;
		
		Scheduler sch = new Scheduler();
		
		floor = new Thread(new FloorSubsystem(sch), "Floor");
		floor.start();
	}
}
