public class Scheduler implements Runnable {
	private boolean empty = true;
	private boolean reply = false;
	private s str;
	private String getDirection(int Direction) {
		if(Direction == 1) {
			return "Up";
		}
		else {
			return "Down";
		}
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	public synchronized void put(s s) {
		while(!empty && !reply) {
			try {
				wait();
			}
			catch(InterruptedException e) {
				return;
			}
		}
		str = s;
		System.out.println("Scheduler recieved message :" + s.time + " " + s.floor + " " + getDirection(s.direction)+ " "+ s.elevator);
		empty = true;
		notifyAll();
	}
	public synchronized s get() {
		while(empty && str != null && !reply) {
			try {
				wait();
			}
			catch(InterruptedException e) {
				return null;
			}
		}
		reply = true;
		empty = true;
		notifyAll();
		return str;
		
	}
	

}