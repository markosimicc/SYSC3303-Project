package scheduler_state;

/**

 * @author Archit Bhatia(states)

 *

 * a list of the transitions of the Schedulers states

 */
import static scheduler_state.Transition_list.Door_Opening;
import static scheduler_state.Transition_list.Reach_Floor;
import static scheduler_state.Transition_list.Start_Motor;
import static scheduler_state.Transition_list.Door_closing;

public class ElevatorSubsystem implements Runnable {
	private int elevatorNum; // Declaration of class fields
	private Scheduler scheduler;
	private RequestInfo info;
	//private static Logger LOGGER = Logger.getLogger(Scheduler.class.getName());
	public State stat = State.Start;
	public Transition_list trans;
	/**
	 * 
	 * Constructor for the Elevator Subsystem class
	 * 
	 * 
	 * 
	 * @param elevatorNum
	 * 
	 * 
	 * 
	 */

	public ElevatorSubsystem(int elevatorNum, Scheduler s) {
		this.elevatorNum = elevatorNum;
		this.scheduler = s;
	}

	/**
	 * 
	 * run() receives the information from the scheduler, prints out a message and
	 * 
	 * sends the information back using an instance of scheduler
	 * 
	 */

	public enum State {
		Start {
			@Override
			public State next(Transition_list transition) {
				return (transition == Door_closing) ? Door_Closed : ILLEGAL;
			}
		},

		Door_Closed {
			@Override
			public State next(Transition_list transition) {
				
				return (transition == Start_Motor) ? Moving : ILLEGAL;
			}
		},

		Moving {
			@Override
			public State next(Transition_list transition) {
				return (transition == Reach_Floor) ? Stopped : ILLEGAL;
			}
		},

		Stopped {
			@Override
			public State next(Transition_list transition) {
				return (transition == Door_Opening) ? Start : ILLEGAL;
			}
		},

		ILLEGAL {
			@Override
			public State next(Transition_list transition) {
				return ILLEGAL;
			}
		};

		public State next(Transition_list transition) {
			return null;
		}
		
		
	}
	  
	public void run() {
		while(true) {
			info = scheduler.recieveInfo(false);
			System.out.println("Elevator Recieved: " + info.time + " " + info.floor + " " + info.direction + " " + info.elevator);
			stat = stat.next(Transition_list.Door_closing);
			System.out.println(stat);
			System.out.println("Elevator " + this.elevatorNum + " is ready to move.");
			stat = stat.next(Transition_list.Start_Motor);
			System.out.println(stat);
			scheduler.sendInfo(info);
			stat = stat.next(Transition_list.Reach_Floor);
			System.out.println(stat);
			stat = stat.next(Transition_list.Door_Opening);
			
			
		}
	}
}