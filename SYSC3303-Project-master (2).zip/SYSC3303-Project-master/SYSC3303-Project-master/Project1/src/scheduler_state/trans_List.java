package scheduler_state;




/**

 * @author Michael Slokar

 *

 * a list of the transitions of the Schedulers states

 */

public enum trans_List {

	RECEIVE,

	SEND;


}
