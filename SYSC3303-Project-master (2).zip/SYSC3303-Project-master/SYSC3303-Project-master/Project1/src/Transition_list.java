
public enum Transition_list {
	Door_Opening,
	Reach_Floor,
	Start_Motor,
	Door_closing;
}
